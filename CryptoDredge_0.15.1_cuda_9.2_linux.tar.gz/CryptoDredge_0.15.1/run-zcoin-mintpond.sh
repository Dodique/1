echo -e '\033]2;MTP (XZC) - mintpond pool\007'
while true
do
  ./CryptoDredge -a mtp -o stratum+tcp://zcoin.mintpond.com:3000 -u aJFbjbmugJr5Hpr1dKpDnJgwRSFueCwzd8.benchmark -p x
done
